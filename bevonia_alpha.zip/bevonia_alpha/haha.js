className = function () {};
className.prototype = {
    // General solutions
}